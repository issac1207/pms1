﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PMS_API.Migrations
{
    public partial class initialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateSequence(
                name: "CustSequence",
                startValue: 100L);

            migrationBuilder.CreateTable(
                name: "FIMaster",
                columns: table => new
                {
                    FIID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FIName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FIDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RateOfInterest = table.Column<int>(type: "int", nullable: false),
                    Tenure = table.Column<int>(type: "int", nullable: false),
                    PurchaseUnitValue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FIMaster", x => x.FIID);
                });

            migrationBuilder.CreateTable(
                name: "MFMaster",
                columns: table => new
                {
                    MFID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FundType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FaceValue = table.Column<int>(type: "int", nullable: false),
                    NAVValue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MFMaster", x => x.MFID);
                });

            migrationBuilder.CreateTable(
                name: "StockMaster",
                columns: table => new
                {
                    StockID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FaceValue = table.Column<int>(type: "int", nullable: false),
                    StockPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockMaster", x => x.StockID);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    userId = table.Column<int>(type: "int", nullable: false, defaultValueSql: "NEXT VALUE FOR CustSequence"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    lastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DOB = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pincode = table.Column<int>(type: "int", nullable: false),
                    PhoneNumber = table.Column<decimal>(type: "decimal(20,0)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.userId);
                });

            migrationBuilder.CreateTable(
                name: "UserFI",
                columns: table => new
                {
                    TransactionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FIID = table.Column<int>(type: "int", nullable: true),
                    FixedIncomeMasterFIID = table.Column<int>(type: "int", nullable: true),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchaseQty = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFI", x => x.TransactionID);
                    table.ForeignKey(
                        name: "FK_UserFI_FIMaster_FixedIncomeMasterFIID",
                        column: x => x.FixedIncomeMasterFIID,
                        principalTable: "FIMaster",
                        principalColumn: "FIID");
                });

            migrationBuilder.CreateTable(
                name: "DailyMFNAVs",
                columns: table => new
                {
                    RecordNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFID = table.Column<int>(type: "int", nullable: true),
                    MutualFundMasterMFID = table.Column<int>(type: "int", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClosingPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyMFNAVs", x => x.RecordNo);
                    table.ForeignKey(
                        name: "FK_DailyMFNAVs_MFMaster_MutualFundMasterMFID",
                        column: x => x.MutualFundMasterMFID,
                        principalTable: "MFMaster",
                        principalColumn: "MFID");
                });

            migrationBuilder.CreateTable(
                name: "UserMF",
                columns: table => new
                {
                    MFTransactionNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFID = table.Column<int>(type: "int", nullable: true),
                    MutualFundMasterMFID = table.Column<int>(type: "int", nullable: true),
                    QuantityPrice = table.Column<int>(type: "int", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchasedQuantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserMF", x => x.MFTransactionNo);
                    table.ForeignKey(
                        name: "FK_UserMF_MFMaster_MutualFundMasterMFID",
                        column: x => x.MutualFundMasterMFID,
                        principalTable: "MFMaster",
                        principalColumn: "MFID");
                });

            migrationBuilder.CreateTable(
                name: "DailyStockPrices",
                columns: table => new
                {
                    RecordNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockID = table.Column<int>(type: "int", nullable: true),
                    StockMasterStockID = table.Column<int>(type: "int", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClosingPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyStockPrices", x => x.RecordNo);
                    table.ForeignKey(
                        name: "FK_DailyStockPrices_StockMaster_StockMasterStockID",
                        column: x => x.StockMasterStockID,
                        principalTable: "StockMaster",
                        principalColumn: "StockID");
                });

            migrationBuilder.CreateTable(
                name: "MyStocks",
                columns: table => new
                {
                    TransactionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockID = table.Column<int>(type: "int", nullable: true),
                    StocksMasterStockID = table.Column<int>(type: "int", nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchasePrice = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MyStocks", x => x.TransactionID);
                    table.ForeignKey(
                        name: "FK_MyStocks_StockMaster_StocksMasterStockID",
                        column: x => x.StocksMasterStockID,
                        principalTable: "StockMaster",
                        principalColumn: "StockID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_DailyMFNAVs_MutualFundMasterMFID",
                table: "DailyMFNAVs",
                column: "MutualFundMasterMFID");

            migrationBuilder.CreateIndex(
                name: "IX_DailyStockPrices_StockMasterStockID",
                table: "DailyStockPrices",
                column: "StockMasterStockID");

            migrationBuilder.CreateIndex(
                name: "IX_MyStocks_StocksMasterStockID",
                table: "MyStocks",
                column: "StocksMasterStockID");

            migrationBuilder.CreateIndex(
                name: "IX_UserFI_FixedIncomeMasterFIID",
                table: "UserFI",
                column: "FixedIncomeMasterFIID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMF_MutualFundMasterMFID",
                table: "UserMF",
                column: "MutualFundMasterMFID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DailyMFNAVs");

            migrationBuilder.DropTable(
                name: "DailyStockPrices");

            migrationBuilder.DropTable(
                name: "MyStocks");

            migrationBuilder.DropTable(
                name: "UserFI");

            migrationBuilder.DropTable(
                name: "UserMF");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "StockMaster");

            migrationBuilder.DropTable(
                name: "FIMaster");

            migrationBuilder.DropTable(
                name: "MFMaster");

            migrationBuilder.DropSequence(
                name: "CustSequence");
        }
    }
}
