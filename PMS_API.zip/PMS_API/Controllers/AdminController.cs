﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMS_API.Models;

namespace PMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        PMS_DbContext db = null;

        public AdminController(PMS_DbContext context)

        {

            this.db = context;

        }
        [HttpPost]

        [Route("AdminLogin")]

        public IActionResult AdminLogin([FromBody] AdminLogin aLog)

        {

            if (aLog.UserName == null || aLog.Password == null)

            {

                return BadRequest();

            }

            if (aLog.UserName == "admin@wipro.com" && aLog.Password == "admin")

            {

                return Ok("Admin Login successfull !!");

            }

            return BadRequest("Admin with provided details doesn't exist!!");

        }
        [HttpGet]
        [Route("GetList")]
        public IActionResult GetList()

        {

            return Ok(db.Users.ToList());

        }

        [HttpGet]

        [Route("GetById/{id}")]

        public IActionResult GetById(int id)

        {

            try

            {

                var user = db.Users.Find(id);

                if (user == null)

                {

                    return Ok("User Id is not present");

                }

                return Ok(user);

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }

    
        [HttpPost]

        [Route("AddCustomer")]

        public IActionResult AddCustomer([FromBody] PMS_User userObj)

        {

            if (userObj == null)

            {

                return BadRequest();

            }

           
                PMS_User customer = new PMS_User();

                customer.FirstName = userObj.FirstName;

                customer.lastName = userObj.lastName;

                customer.DOB = userObj.DOB;

                customer.Gender = userObj.Gender;

                customer.Address = userObj.Address;

                customer.City = userObj.City;

                customer.State = userObj.State;

                customer.Country = userObj.Country;

                customer.PhoneNumber = userObj.PhoneNumber;
                customer.Email = userObj.Email;
                customer.password = userObj.password;
                customer.Pincode = userObj.Pincode;


                db.Users.Add(customer);

                db.SaveChanges();

                return Ok("User Registration Successfull !!");

            

            return BadRequest("Invalid Registration .. ");

        }
        //[HttpPut]

        //[Route("EditCustomer/{id}")]

        //public IActionResult UpdateuserDetails([FromBody] UserModel user, int id)

        //{

        //    if (id == null)

        //    {

        //        return BadRequest();

        //    }

        //    var userToBeUpdated = db.Users.Find(id);

        //    if (userToBeUpdated.userId == id)

        //    {
        //        userToBeUpdated.userId = id;

        //        userToBeUpdated.Email = user.Email;

        //        userToBeUpdated.DOB = user.DOB;

        //        userToBeUpdated.FirstName = user.FirstName;

        //        userToBeUpdated.lastName = user.lastName;

        //        userToBeUpdated.Gender = user.Gender;

        //        userToBeUpdated.Address = user.Address;

        //        userToBeUpdated.State = user.State;

        //        userToBeUpdated.City = user.City;

        //        userToBeUpdated.Country = user.Country;

        //        userToBeUpdated.Pincode = user.Pincode;

        //        userToBeUpdated.PhoneNumber = user.PhoneNumber;

        //        db.Users.Update(userToBeUpdated);

        //        db.SaveChanges();

        //        return Ok("Details Updated successfully !!");

        //    }

        //    return BadRequest("Invalid Details...");

        //}
        [HttpPut]
        [Route("EditCustomer/{id}")]
        public IActionResult UpdateCustomerDetails([FromBody] UserModel customer, int id)

        {

            if (id == null)

            {

                return BadRequest();

            }

            var customerToBeUpdated = db.Users.Find(id);

            if (customerToBeUpdated.userId == id)

            {
                customerToBeUpdated.FirstName = customer.FirstName;

                customerToBeUpdated.lastName = customer.lastName;

                customerToBeUpdated.DOB = customer.DOB;
                customerToBeUpdated.Address = customer.Address;
                customerToBeUpdated.City = customer.City;
                customerToBeUpdated.State = customer.State;
                customerToBeUpdated.Country = customer.Country;
                customerToBeUpdated.Pincode = customer.Pincode;
                customerToBeUpdated.PhoneNumber = customer.PhoneNumber;
                customerToBeUpdated.Email = customer.Email;
                customerToBeUpdated.Gender = customer.Gender;


                db.Users.Update(customerToBeUpdated);

                db.SaveChanges();

                return Ok("Customer details Updated successfully !!");

            }

            return BadRequest("Invalid Customer Details...");

        }

        [HttpDelete]
        [Route("DeleteCustomer/{id}")]
        public IActionResult DeleteUser(int id)

        {

            if (id == null)

            {

                return BadRequest();

            }

            var userToBeDeleted = db.Users.Find(id);

            if (userToBeDeleted != null)

            {

                db.Users.Remove(userToBeDeleted);

                db.SaveChanges();

                return Ok("User Deleted successfully !!");

            }

            return BadRequest("User with provided details doesn't exist!!");

        }

    }
}

