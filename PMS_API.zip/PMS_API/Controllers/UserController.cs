﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMS_API.Models;
namespace PMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        PMS_DbContext db = null;
        public UserController(PMS_DbContext context)
        {
            this.db = context;
        }
        [HttpPost]
        [Route("UserRegister")]
        public IActionResult AddUser([FromBody] PMS_User userObj)
        {
            if (userObj == null)
            {
                return BadRequest();
            }
            PMS_User customer = new PMS_User();
            customer.FirstName = userObj.FirstName;
            customer.lastName = userObj.lastName;
            customer.DOB = userObj.DOB;
            customer.Gender = userObj.Gender;
            customer.Address = userObj.Address;
            customer.City = userObj.City;
            customer.State = userObj.State;
            customer.Country = userObj.Country;
            customer.PhoneNumber = userObj.PhoneNumber;
            customer.Email = userObj.Email;
            customer.password = userObj.password;
            customer.Pincode = userObj.Pincode;
            db.Users.Add(customer);
            db.SaveChanges();
            return Ok("User Registration Successfull !!");
            return BadRequest("Invalid Registration .. ");
        }
    }
}
