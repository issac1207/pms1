﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{
    public class MutualFundModel
    {
        [Key]

        public int MFTransactionNo { get; set; }

        public int? MFID { get; set; }

        public virtual MutualFundMaster? MutualFundMaster { get; set; }

        public int QuantityPrice { get; set; }

        public DateTime PurchaseDate { get; set; }

        public int PurchasedQuantity { get; set; }

    }

}