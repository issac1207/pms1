﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{
    public class MutualFundMaster
    {
        [Key]
        public int MFID { get; set; }
        public string MFName { get; set; }
        public string FundType { get; set; }
        public int FaceValue { get; set; }
        public int NAVValue { get; set; }
    }
}
