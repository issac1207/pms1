﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{
    public class Stocks
    {
        [Key]
        public int TransactionID { get; set; }
        public int? StockID { get; set; }
        public virtual StocksMaster? StocksMaster { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchaseDate { get; set; }
        public int PurchasePrice { get; set; }
        public double Amount { get; set; }
    }
}
