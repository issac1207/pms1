﻿using Microsoft.EntityFrameworkCore;

namespace PMS_API.Models
{
    public class PMS_DbContext : DbContext
    {
        public PMS_DbContext(DbContextOptions<PMS_DbContext> options) : base(options)
        {
            
        }
      
      
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            modelBuilder.HasSequence("CustSequence")
                 .StartsAt(100).IncrementsBy(1);
            modelBuilder.Entity<PMS_User>()
                .Property(c => c.userId)
                .HasDefaultValueSql("NEXT VALUE FOR CustSequence");



            base.OnModelCreating(modelBuilder);
        }



        public virtual DbSet<PMS_User> Users { get; set; }
        public virtual DbSet<StocksMaster> StockMaster { get; set; }
        public virtual DbSet<Stocks> MyStocks { get; set; }
        public virtual DbSet<MutualFundMaster> MFMaster { get; set; }
        public virtual DbSet<MutualFundModel> UserMF { get; set; }
        public virtual DbSet<FixedIncomeMasterModel> FIMaster { get; set; }
        public virtual DbSet<FixedIncome> UserFI { get; set; }
        public virtual DbSet<DailyStockPrice> DailyStockPrices { get; set; }
        public virtual DbSet<DailyMFNav> DailyMFNAVs { get; set; }

    }
}
