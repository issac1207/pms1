﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models

{

    public class DailyStockPrice

    {

        [Key]

        public int RecordNo { get; set; }

        public int? StockID { get; set; }

        public virtual StocksMaster? StockMaster { get; set; }

        public DateTime Date { get; set; }

        public int ClosingPrice { get; set; }

    }

}

