﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{
    public class DailyMFNav
    {
        [Key]

        public int RecordNo { get; set; }

        public int? MFID { get; set; }

        public virtual MutualFundMaster? MutualFundMaster { get; set; }

        public DateTime Date { get; set; }

        public int ClosingPrice { get; set; }

    }

}