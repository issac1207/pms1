﻿using System.ComponentModel.DataAnnotations;

namespace PMS_API.Models
{
    public class UserLogin
    {
        [Required]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
