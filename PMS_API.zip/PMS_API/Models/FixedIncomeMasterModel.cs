﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{

    public class FixedIncomeMasterModel

    {

        [Key]

        public int FIID { get; set; }

        public string FIName { get; set; }

        public string FIDescription { get; set; }

        public int RateOfInterest { get; set; }

        public int Tenure { get; set; }

        public int PurchaseUnitValue { get; set; }

    }

}