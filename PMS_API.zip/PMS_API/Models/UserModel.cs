﻿using System.ComponentModel.DataAnnotations;

namespace PMS_API.Models
{
    public class UserModel
    {

        
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string lastName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get;set; } 
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        public int Pincode { get; set; }
        [Required]
        public ulong PhoneNumber { get; set; }
    }
}
