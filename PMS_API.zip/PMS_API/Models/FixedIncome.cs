﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{

    public class FixedIncome
    {

        [Key]

        public int TransactionID { get; set; }

        public int? FIID { get; set; }

        public virtual FixedIncomeMasterModel? FixedIncomeMaster { get; set; }

        public DateTime PurchaseDate { get; set; }

        public int PurchaseQty { get; set; }

        public int Amount { get; set; }

    }

}