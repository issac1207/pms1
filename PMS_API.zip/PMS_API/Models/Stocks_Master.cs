﻿using System.ComponentModel.DataAnnotations;
namespace PMS_API.Models
{
    public class StocksMaster
    {
        [Key]
        public int StockID { get; set; }
        public string StockName { get; set; }
        public int FaceValue { get; set; }
        public int StockPrice { get; set; }
    }
}