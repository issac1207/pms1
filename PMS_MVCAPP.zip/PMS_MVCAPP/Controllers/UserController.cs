﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PMS_MVCAPP.Models;
using System.Text;

namespace PMS_MVCAPP.Controllers
{
    public class UserController : Controller
    {
        [BindProperty]
        public UserModel User { get; set; }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult UserRegister()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UserRegister(PMS_User cusObj)
        {
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(cusObj)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = httpclient.PostAsync("http://localhost:10978/api/User/UserRegister", content))
                {
                    if (response.Result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Registration";
                    }
                }
            }
            return View();
        }
    }
}
