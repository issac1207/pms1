﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PMS_MVCAPP.Models;
using System.Text;

namespace PMS_MVCAPP.Controllers
{
    public class AdminController : Controller
    {
        [BindProperty]
        public UserModel User { get; set; }
        public async Task<IActionResult> Index()
        {
            try
            {
                List<UserModel> customersList = new List<UserModel>();
                using (var httpClient = new HttpClient())
                {
                    //replace the portnumber with the Ocelot Gateway portnumber
                    using (var response
                        = await httpClient.GetAsync("http://localhost:10978/api/Admin/GetList"))
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        customersList = JsonConvert.DeserializeObject<List<UserModel>>(apiResponse);
                    }
                }
                return View(customersList);
            }
            catch (Exception ex)
            {

                return RedirectToAction("Error");
            }
        }

        public IActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AdminLogin(AdminLogin aLog)
        {
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(aLog)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = httpclient.PostAsync("http://localhost:10978/api/Admin/AdminLogin", content))
                {
                    if (response.Result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Login";
                    }
                }
            }
            return View();
        }
        public IActionResult SearchById()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> SearchByIds(int id)
        {
            PMS_User s = new PMS_User();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:10978/api/Admin/GetById/" + id))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    if (apiResponse == "User Id is not present")
                    {
                        return RedirectToAction("Results", new { m = apiResponse });
                    }
                    s = JsonConvert.DeserializeObject<PMS_User>(apiResponse);
                    return RedirectToAction("Result", s);
                }
            }
            return View();
        }
        public IActionResult Results(string m)
        {
            ViewBag.Name = m;
            return View();
        }
        public IActionResult Result(PMS_User m)
        {
            return View(m);
        }
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                UserModel customer = null;
                using (var httpClient = new HttpClient())
                {
                    //replace the portnumber with the Ocelot Gateway portnumber
                    using (var response = await httpClient.GetAsync("http://localhost:10978/api/Admin/GetById/" + id))
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        customer = JsonConvert.DeserializeObject<UserModel>(apiResponse);
                    }
                }
                return View(customer);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
        public IActionResult RegisterCustomer()
        {
            return View();
        }
        [HttpPost]
        public IActionResult RegisterCustomer(PMS_User cusObj)
        {
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(cusObj)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = httpclient.PostAsync("http://localhost:10978/api/Admin/AddCustomer", content))
                {
                    if (response.Result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Registration";
                    }
                }
            }
            return View();
        }
        public async Task<IActionResult> Edit(int id)

        {

            UserModel user = null;

            using (var httpclient = new HttpClient())

            {

                using (var response = await httpclient.GetAsync("http://localhost:10978/api/Admin/GetById/" + id))

                {

                    var apiresponse = await response.Content.ReadAsStringAsync();

                    user = JsonConvert.DeserializeObject<UserModel>(apiresponse);

                }

            }

            return View(user);

        }

        [HttpPost]
        public async Task<IActionResult> Edit(UserModel custObj, int id)
        {
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(custObj), Encoding.UTF8, "application/json");
                using (var response = await httpclient.PutAsync("http://localhost:10978/api/Admin/EditCustomer/" + id, content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Customer Update";
                    }
                }
            }
            return View(custObj);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            if (ModelState.IsValid)
            {
                using (var httpclient = new HttpClient())
                {
                    using (var response = httpclient.DeleteAsync("http://localhost:10978/api/Admin/DeleteCustomer/" + id))
                    {
                        if (response.Result.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ViewData["Message"] = "Customer Deletion failed!!";
                        }
                    }
                }
            }
            return View();
        }
    }
}
