﻿using System.ComponentModel.DataAnnotations;


namespace PMS_MVCAPP.Models
{
    public class AdminLogin
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

    }
}
